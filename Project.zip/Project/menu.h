#ifndef MENU_H
#define MENU_H
#include <iostream>
#include <fstream>
#include <vector>
#include <exception>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <time.h>
#include <string.h>
#include <conio.h>
#include <Windows.h>
#define PI 3.141
#define encryptionvalue 10;

using namespace std;
class menu
{
public:
    static void main_menu()
    {
        cout << endl
             << endl
             << endl;
        cout << "\t\t\t---WELCOME TO BLOOD BANK MANAGEMENT SYSTEM---" << endl
             << endl;
        cout << "\t\t\t----------------- MAIN MENU ------------------" << endl;
        cout << "\n\t\t\t1)Admin\n\t\t\t2)Citizen\n\t\t\t3)Hospital\n\t\t\t4)Exit" << endl
             << endl;
        cout << "\t\t\tEnter Your Choice: ";
    }

    static void admin_menu()
    {
        cout << endl
             << endl
             << endl;
        cout << "\t\t\t-------------- WELCOME ADMIN ----------------" << endl;
        cout << "\n\t\t\t1)See Records\n\t\t\t2)Search Records\n\t\t\t3)Remove Record\n\t\t\t4)See blood reserves\n\t\t\t5)Logout" << endl
             << endl;
        cout << "\t\t\tEnter Your Choice: ";
    }

    static void citizen_menu()
    {
        cout << endl
             << endl
             << endl;
        cout << "\t\t\t-------------- CITIZEN MENU -----------------" << endl;
        cout << "\n\t\t\tWelcome! Login if you have already registered otherwise select register" << endl;
        cout << "\n\t\t\t1)Login\n\t\t\t2)Register\n\t\t\t3)Go Back" << endl
             << endl;
        cout << "\t\t\tEnter Your Choice: ";
    }

    static void citizen_menu(string name)
    {
        cout << endl
             << endl
             << endl;
        cout << "\t\t\t-------------- WELCOME " << name << " ----------------" << endl;
        cout << "\n\t\t\t1)Donate Blood\n\t\t\t2)Order Blood\n\t\t\t3)Change Password\n\t\t\t4)Logout" << endl
             << endl;
        cout << "\t\t\tEnter Your Choice: ";
    }

    static void hospital_menu(string name)
    {
        cout << endl
             << endl
             << endl;
        cout << "\t\t\t-------------- WELCOME " << name << " ----------------" << endl;
        cout << "\n\t\t\t1)Update Emergency Status(ON/OFF)\n\t\t\t2)Order Blood\n\t\t\t3)Logout" << endl
             << endl;
        cout << "\t\t\tEnter Your Choice: ";
    }
};

#endif